package java_1020;

public class A2 {

	public static void main(String[] args) {
		int[] arr = {1,2,3,4};
		
		for (int i : arr) {
			i--;
			System.out.println(arr[i]);
		}
		
		

	}

}
