package java_1020;

interface Car{}

class Sonata implements Car {}

class K5 implements Car {}

public class A4 {

	public static void main(String[] args) {
		Car car = new K5(); 
		Car car1 = new Sonata(); 
			
		}

}


