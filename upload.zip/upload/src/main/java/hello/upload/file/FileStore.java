package hello.upload.file;

import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartFile;

import hello.upload.domain.Uploadfile;
import lombok.extern.slf4j.Slf4j;

// 파일 저장 관련 기능
@Slf4j
@Component
public class FileStore {
	@Value("${file.dir}") // application.properties 파일 값 가져오기(빈주입 형태)
	private String fileDir;
	
	// 파일 저장 경로 + 파일명.확장자
	public String getFullPath(String fileName) {
		String fullPath = fileDir + fileName;
		log.info("fullPath={}", fullPath);
		
		return fullPath;
	}
	
	
	// 다중 파일 업로드
	public List<Uploadfile> storeFiles(List<MultipartFile> multipartFiles) throws IllegalStateException, IOException{
		List<Uploadfile> storeFileResult = new ArrayList<>();
		
		for(MultipartFile file : multipartFiles) {
			if(!file.isEmpty()) {  
				// 아무 글자도 입력하지 않은 메모장파일(.txt)을 업로드하는 경우, 
				// 파일의 byte 크기가 0이므로 isEmpty() 결과가 true임
				storeFileResult.add(storeFile(file)); // 넘어오는 파일을 각각 저장
			}
		}
		return storeFileResult;
		
	}

	// 단일 파일 업로드
	public Uploadfile storeFile(MultipartFile multipartFile) throws IllegalStateException, IOException {
		
		if(multipartFile.isEmpty()) {
			return null;
		}
		
		// 업로드한 원본 파일명
		String originalFilename = multipartFile.getOriginalFilename();
		
		// uuid로 만든 고유파일명 (dsfsffs-sfsfsfsf-sffsfs.txt)
		String storeFilename = createFileName(originalFilename);
		// 파일 저장경로 + uuid 파일명
		// C:\\Users\\admin\\study\\file\dsfsffs-sfsfsfsf-sffsfs.txt
		String fullPath = fileDir + storeFilename;
		// 파일저장
		multipartFile.transferTo(new File(fullPath));
		
		return new Uploadfile(originalFilename, storeFilename);
	}
	
	
	// UUID 파일 이름 생성
	private String createFileName(String originalFileName) { ///t.txt
		// 파일 확장자 가져오기
		int pos = originalFileName.lastIndexOf(".");
		String ext = originalFileName.substring(pos+1);
		
		// 랜덤값 생성 (업로드 파일명이랑 상관 없음)
		String uuid = UUID.randomUUID().toString();
		
		return uuid + "." + ext;
	}
	
}
