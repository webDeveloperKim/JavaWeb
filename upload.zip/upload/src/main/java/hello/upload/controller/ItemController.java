package hello.upload.controller;

import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.charset.StandardCharsets;
import java.util.List;

import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.web.util.UriUtils;

import hello.upload.domain.Item;
import hello.upload.domain.ItemRepository;
import hello.upload.domain.Uploadfile;
import hello.upload.file.FileStore;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;

// 과제 : 아래의 객체들 활용하여, 컨트롤러 1,2,3 구현 
// ItemForm, UploadFile, FileStore, ItemRepository

@Slf4j
@Controller
@RequiredArgsConstructor
public class ItemController {
	private final ItemRepository itemRepository;
	private final FileStore fileStore;
	
	// 1. 등록폼 s
	// getmapping("/items/new")
	// return "item-form";
	@GetMapping("/items/new")
	public String getForm() {
		
		return "item-form";
	}
	
	// 2. 등록폼에서 데이터 저장하고, 저장한 화면으로 리다이렉트
	// postmapping("/items/new")
	// return "redirect:/items/{itemId}";
	
	@PostMapping("/items/new")
	public String saveForm(ItemForm form, RedirectAttributes redirectAttributes) throws IllegalStateException, IOException {
		MultipartFile multipartFile = form.getAttachFile();
		Uploadfile uploadfile = fileStore.storeFile(multipartFile);
		
		List<Uploadfile> uploadfiles = fileStore.storeFiles(form.getImageFiles());
		
		log.info("uploadfiles={}", uploadfiles);
		
		// DB 저장부분
		Item item = new Item();
		item.setItemName(form.getItemName());
		item.setAttachFile(uploadfile);
		item.setImageFiles(uploadfiles); // 누락된 코드
		
		item = itemRepository.save(item);
		
		redirectAttributes.addAttribute("id", item.getId());
		
		return "redirect:/items/{id}";
	}

	@GetMapping("/items/{id}")
	public String getResultForm(@PathVariable("id") Long id, Model model) {
		Item item = itemRepository.findById(id);	
		
		
		model.addAttribute("item", item);
		log.info("컨트롤러 호출 test1");
		log.info("ImageFiles={}", item.getImageFiles());
		
		return "item-view";
	}
	
	@ResponseBody
	@GetMapping("/images/{storeFileName}")
	public UrlResource downloadImages(@PathVariable("storeFileName") String storeFileName) throws MalformedURLException {
		log.info("컨트롤러 호출 test2");
		
		log.info("fileName={}", storeFileName);
//		log.info("UrlObj={}", new UrlResource(fileStore.getFullPath(fileName)));
		
		// 로컬 파일을 웹브라우저에서 접근하려고 할때
		// 로컬 경로 앞 file: 프로토콜을 추가해주어야 함
		//new UrlResource("file:" + fileStore.getFullPath(storeFileName))
		//return new UrlResource("file:" + fileStore.getFullPath(storeFileName));
		
		// 맥북에선 file 빼야 다운로드 가능
		return new UrlResource(fileStore.getFullPath(storeFileName));
		
	}
	
	@ResponseBody
	@GetMapping("/attach/{id}")
	public ResponseEntity<Resource> downloadAttach(@PathVariable("id") Long id) throws MalformedURLException{
		Item item = itemRepository.findById(id); // 아이디로 상품 조회
		String storeFileName = item.getAttachFile().getStoreFileName(); // uuid
		String uploadFileName =  item.getAttachFile().getUploadFileName(); // 사용자가 등록한 파일명
		log.info("storeFileName={}", storeFileName);
		log.info("uploadFileName={}", uploadFileName); 
		
		UrlResource urlResource = new UrlResource("file:" + fileStore.getFullPath(storeFileName));
		log.info("urlResource={}", urlResource);
		
		String encodedUploadFileName = UriUtils.encode(uploadFileName, StandardCharsets.UTF_8);
		log.info("contDisposition={}", encodedUploadFileName);
		String contDisposition = "attachment; filename=\"" + encodedUploadFileName + "\"";
		log.info("contDisposition={}", contDisposition);

		return ResponseEntity.ok()
				.header(HttpHeaders.CONTENT_DISPOSITION, contDisposition)
				.body(urlResource);
	}
}





















