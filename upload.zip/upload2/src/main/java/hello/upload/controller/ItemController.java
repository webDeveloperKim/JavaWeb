package hello.upload.controller;

import java.io.IOException;

import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;

import hello.upload.domain.Item;
import hello.upload.domain.ItemRepository;
import hello.upload.domain.Uploadfile;
import hello.upload.file.FileStore;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;


// 과제 : 아래의 객체들 활용하여, 컨트롤러 1,2,3 구현 
// ItemForm, UploadFile, FileStore, ItemRepository

@Slf4j
@Controller
@RequiredArgsConstructor
public class ItemController {
	private final ItemRepository itemRepository;
	private final FileStore fileStore;
	
	// 1. 등록폼 
	// getmapping("/items/new")
	// return "item-form";
	 @GetMapping("/items/new")
	    public String newItemForm(Model model) {
	        model.addAttribute("itemForm", new ItemForm());
	        return "item-form"; // item-form.html 뷰를 반환
	    }
	
	// 2. 등록폼에서 데이터 저장하고, 저장한 화면으로 리다이렉트
	// postmapping("/items/new")
	// return "redirect:/items/{itemId}";
	 @PostMapping("/items/new")
	    public String saveItem(@ModelAttribute ItemForm itemForm) throws IOException {
	        // 상품 정보 저장
	        Item item = new Item();
	        item.setItemName(itemForm.getItemName());

	        // 파일 저장
	        List<Uploadfile> uploadFiles = fileStore.storeFiles(itemForm.getImagesFiles());

	        // 첨부 파일이 있으면, 업로드된 파일을 Item에 저장
	        item.setImageFiles(uploadFiles);

	        // 상품 저장
	        Item savedItem = itemRepository.save(item);

	        // 상품 상세 화면으로 리다이렉트
	        return "redirect:/items/" + savedItem.getId();
	    }

	
	// 3. 등록한 상품+첨부파일 보여주기
	// getmapping("/item/{id}")
	// return "item-view";
	 @GetMapping("/item/{Id}")
	    public String viewItem(@PathVariable Long itemId, Model model) {
	        Item item = itemRepository.findById(itemId);
	        if (item == null) {
	            throw new IllegalArgumentException("Item not found, id=" + itemId);
	        }

	        model.addAttribute("item", item);
	        return "item-view"; // item-view.html 뷰를 반환
	    }	
}