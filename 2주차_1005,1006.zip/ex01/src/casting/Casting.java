package casting;

import java.util.Scanner;

public class Casting {

	public static void main(String[] args) {
//	명시적 형변환(=캐스팅)
		
		double doubleValue = 1.5;
		int intValue = 0;
		
		intValue = (int)doubleValue;
//		intValue = (int)doubleValue;

		System.out.println(intValue);
		
//		묵시적 형변환 더 작은 값은 큰 값에 담기는 건 개발자가 
//		해줄 필요 없이 자동으로 해준다.
		doubleValue = intValue;
	
		Scanner scanner = new Scanner(System.in);
		String str = scanner.nextLine(); //문자를 int하는게 더 깔끔
		int a = Integer.parseInt(str); //parseInt : String 타입을 받아서 매개변수 반환하는 기능
		System.out.println(a);
		
	}
	

}
