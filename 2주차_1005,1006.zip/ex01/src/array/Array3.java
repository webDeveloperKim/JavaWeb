package array;

public class Array3 {

	public static void main(String[] args) {
//		배열의 생성과 초기화
		
		int[] students_a = new int[] {90,80,70,60,50};
		int[] students_b = {90,80,70,60,50};
		
		
		
		
		}
		
		
	}


