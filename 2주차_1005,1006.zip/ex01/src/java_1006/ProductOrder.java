package java_1006;

public class ProductOrder {
	
	String productName;
	int price;
	int quantity;
	
}
