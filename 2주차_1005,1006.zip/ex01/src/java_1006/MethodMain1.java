package java_1006;

public class MethodMain1 {

	public static void main(String[] args) {
		// 메서드 동작하는지 확인
		
		Method method = new Method();
		System.out.println(method.add(12,19));
		
	}

}
