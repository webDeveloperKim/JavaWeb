package java_1006;

public class MusicPlayerDataMain {

	public static void main(String[] args) {
		MusicPlayerData data = new MusicPlayerData();
		
		data.isOn = false;
		data.volume = 0;
		
		String result = "";
		result = data.on(10);
		
		System.out.println(result);
		
		
	}
	
		
		
}


