package java_1006;

public class MovieReviewMain {

	public static void main(String[] args) {
//		영화 리뷰 정보 초기화
//		영화 리뷰 정보 출력
		
//		인사이드아웃2 , 리뷰 : 재밌다
//		어바웃타임 , 리뷰  : 재밌다2
		
		MovieReview movie1 = new MovieReview(); 
		MovieReview movie2 = new MovieReview(); 

		MovieReview[] movieReviews = new MovieReview[]{movie1, movie2};
		movieReviews[0].title = "인사이드아웃2";
		movieReviews[0].review = "재밌다";
		movieReviews[1].title = "어바웃타임";
		movieReviews[1].review = "재밌다2";
		
		
		System.out.println("영화 제목 : " + movieReviews[0].title + "영화 리뷰 : " + movieReviews[0].review);
		System.out.println("영화 제목 : " + movieReviews[1].title + "영화 리뷰 : " + movieReviews[1].review);
		
	}

}
