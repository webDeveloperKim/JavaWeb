package java_1006;

public class MovieReview {

	String title; // 영화제목
	String review; // 영화 리뷰 내용
}
