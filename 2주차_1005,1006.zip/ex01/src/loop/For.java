package loop;

public class For {

	public static void main(String[] args) {
//	for(초기식; 조건식; 증감식)
		
		for(int i = 1; i <= 10; i++) {
			System.out.println(i);
		}

//		for문은 반복횟수에 직접적인 영향을 주는 변수 선언,
//		그 변수를 조건식에서 활용, 그변수를 증감 조건을 통해서

		int sum = 0;
		int endNum = 3;
//		for문으로 1부터 3까지 반복하면서 sum 누적된 합 최종 출력
		
		for(int i = 0; i <= endNum; i++) {
			sum += sum + i;
		}
		System.out.println("sum : "+sum);
		
		for(int num = 2, count = 1; count <= 10; num += 2, count++) {
			System.out.println(num);
		}
	}

}
