package a_variable;

public class Hello {

	// 자바 프로그램의 시작점 main 매서드
	public static void main(String[] args) {
		// TODO Auto-generated method stub
//	모든 코드는 중괄호 {} 블록으로 감싸고 있음
//	outline 현재 작성중인 코드에 있는 구성요소의 계층화
//			
		
	}

}
