package operator;

public class Operator5 {

	public static void main(String[] args) {
//		전위 증감연산자 ( 증감연산을 수행하고 다른연산을 수행함 )
		
		int a = 1;
		int b = 0;
		
		b = ++a; // a의 값을 먼저 1 증가 시키고, 그 결과를 b에 대입한다
		
		a = 1; 
		b = 0;
		
		b = a++; //a의 현재 값을 b에 먼저 대입연산 하고 그 이후에 값을 1 증가시킨
		
	}

}
