package operator;

public class Assign {

	public static void main(String[] args) {
//		복합대입연산자 ( =축약연산자 )
		int a = 5;
		
//		a += 3; // a = a + 3;
//		a -= 3; // a = a - 3;
//		a *= 3; // a = a * 3;
//		a /= 3; // a = a / 3;
//		a %= 3; // a = a % 3;

		System.out.println(a += 3);
		System.out.println(a);
		
	}

}
