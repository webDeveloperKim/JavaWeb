package operator.ex;

public class OperatorEx3 {

	public static void main(String[] args) {
//		문제3
//		int형 score 를 선언
//		score가 80점 이상이고 , 100점 이하이면 true 를 출력
//		아니면 false를 출력
		
		int score = 0; //지역변수는 초기화 해야함
		boolean result = (80 <= score) || (score <= 100);
		
		System.out.println(result);
		
		if(result) {
			System.out.println("true");
		}else {
			System.out.println("false");
		}

	}

}
