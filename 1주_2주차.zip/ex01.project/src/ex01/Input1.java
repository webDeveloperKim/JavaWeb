package ex01;

import java.util.Scanner;

public class Input1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
	//	char keyCode = System.in.read();
		Scanner sc = new Scanner(System.in);
		String aa = sc.next();
		
		System.out.println(aa); 
		System.out.println(sc.next());
	
	// 이클립스 사용하지 않는 Import 자원 삭제 단축
	// 
		
		
		
		
		
	}

}
