package ex01;

public class EnhanceFor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int[] arr = {10,20,30,40,50};
		int sum = 0;
		
		System.out.println("------기본 for문------");
		for(int i = 0; i < arr.length; i++) {
			System.out.println(arr[i]);
		}
		System.out.println("------향상 for문------");
		for(int tmp : arr) {
			System.out.println(tmp);
		}
		
	}

}
