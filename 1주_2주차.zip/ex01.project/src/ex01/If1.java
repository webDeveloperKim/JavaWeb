package ex01;

import java.util.Scanner;

public class If1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int input;
		
		System.out.println("숫자를 입력하세요.");
		
		Scanner scanner = new Scanner(System.in);
		String str = scanner.nextLine();
		input = Integer.parseInt(str);
		
		if(input == 0) {
			
			System.out.println("입력하신 숫자는 0 입니다.");
		}else if(input != 0) {
			System.out.println("입력하신 숫자는 0이 아닙니다.");
			System.out.printf("입력하신 숫자는 %d 입니다.",input);
		}
	}
}