package ex01;

public class Escape4 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		//printf 는 특정한 문자 형식에 맞춰서 출력하게 해줌
		String st = "JAVA_HOME";
		int aa = 123123123;
		
		System.out.printf("jdk가 설치된 경로 : %s \t %d", st,aa);
		
	}

}
