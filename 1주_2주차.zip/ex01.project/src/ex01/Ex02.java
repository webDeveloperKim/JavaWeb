package ex01;

public class Ex02 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		for(int i = 1; i <= 100; i++) {
			System.out.printf("i = %d",i);
			
			int tmp = i;
			
			while ((tmp /= 10) != 0) {
				if(tmp%10%3 == 00 && tmp%10 != 0) {
					System.out.println("짝");
				}
				System.out.println();
			}
			
		}
		
	}

}
