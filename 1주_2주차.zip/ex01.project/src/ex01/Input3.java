package ex01;

public class Input3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int x = 5;
		int y = 3;
		
		//System.out.printf("x+y=%d+%d\n",x,y);
		//System.out.printf("x-y=%d-%d\n",x,y);
		//System.out.printf("x*y=%d*%d\n",x,y);
		//System.out.printf("x/y=%d/%d\n",x,y);
		
		System.out.println("x+y= " + x+y);
		System.out.println("x+y= " + (int)(x+y));
		System.out.println("x+y= " + (x+y));
		System.out.println("x+y= " + (int)(x+y));
		
		String str = 2 + "학년" + 10 + "반";
		System.out.println(str);
		String str2 = "학년" + 2 + 10;
		System.out.println(str2);
		
		
	}

}
