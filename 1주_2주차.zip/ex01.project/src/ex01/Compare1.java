package ex01;

public class Compare1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		int a = 10;
		int b = 5;
		
		System.out.println(a==b);
		System.out.println(!(a==b));
		System.out.println(a!=b);
		System.out.println(a>b);
		System.out.println(a>=b);
		System.out.println(a<b);
		System.out.println(a<=b);
		
		int x = 10;
		int y = 10;
		int c = 10;
		int d = 10;
		int e = 10;
		
		System.out.println(x += 3);
		System.out.println(y -= 3);
		System.out.println(c *= 3);
		System.out.println(d /= 3);
		System.out.println(e %= 3);
		
	}

}
