package ex01;

public class Escape3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String st = "가가가";
		String st2 = "나나나";
		
		System.out.println(st);
		System.out.println(st2);
		System.out.println("------------------");
		System.out.print(st);
		System.out.print(st);
		
	}

}
