package ex01.project;


public class TestClass {
	public static void main(String[] args) {
		System.out.println("hello world");
		// dsdggsdfsf
/*클래스는 대문자 , 매서드는 소문자
 * 
 * 
 *
 * 
 * 
 * 
 * 		
 */
	}
}
