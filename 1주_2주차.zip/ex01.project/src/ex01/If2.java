package ex01;

import java.util.Scanner;

public class If2 {

	public static void main(String[] args) {
		//학생 점수 입력 받기	
		//입력받은 학생 점수가 90점 이상이면 A
		//입력받은 학생 점수가 80점 이상아면 B
		//입력받은 학생 점수가 70점 이상이면 C
		//나머지는 D
		//마지막에 학생에게 입력받은 점수의 등급 알려주는 프로그램
	
		int score = 0;
		char grade = ' ';
		
		System.out.println("점수를 입력하세요 >.");
		Scanner scanner = new Scanner(System.in);
		score = Integer.parseInt(scanner.nextLine());
		
		if(score >= 90) {
			grade = 'A';
		}else if (score >= 80) {
			grade = 'B';
		}else if (score >= 70) {
			grade = 'c';
		}else {
			grade = 'D';
		}
		
		System.out.printf("당신의 학점은 %c 입니다.", grade);
		
	}
}