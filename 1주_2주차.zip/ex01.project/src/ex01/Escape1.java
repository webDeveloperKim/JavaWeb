package ex01;

public class Escape1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String name = "\"홍길동\"";
		//""홍길동""을 쓰는 것은 문법상 맞지 않음
		// \를 쓰면 그 다음에 오는 문자는 의미 있는 문자다
		
		name = "\t홍길동";
		// \n
		
		System.out.println(name);
		
	}

}
