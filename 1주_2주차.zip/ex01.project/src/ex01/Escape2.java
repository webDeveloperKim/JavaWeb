package ex01;

public class Escape2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		String st = "가가가";
		String st2 = "나나나";
		
		System.out.println(st+st2);
		//System.out.println(st,st2);
		//안됨
		 
		
	}

}
