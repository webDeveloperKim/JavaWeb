package ex01; al String recruitName = "25년도 대졸공채";
	recruitName = "상시 채용";
	//final 키워드 붙어서 상수라 안 바뀜
	int age = 1234; //age 변수명 , 1234 : 리터럴
	char ch = '가';
	String st = "가가가";
	
	System.out.println("이번채용공고는 : " + recruitName);
	}
}
