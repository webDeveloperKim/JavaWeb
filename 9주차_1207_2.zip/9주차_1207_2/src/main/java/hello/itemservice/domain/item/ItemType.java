package hello.itemservice.domain.item;

import lombok.Getter;

public enum ItemType {
	
	BOOK("도서"), FOOD("식품"), ETC("기타"); // 상품종류
	
	private final String description; // 상품에 대한 설명
	
	ItemType(String description) {
		this.description = description; 
	}
	
	public String getDescription() {
		return description;
	}
	
}
