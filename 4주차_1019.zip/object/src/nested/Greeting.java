package nested;

public interface Greeting {
	void sayHello();
}
