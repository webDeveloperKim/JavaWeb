package wrapper;

// 예제2 : Double 래퍼 클래스를 사용해서 소수점 계산 수행하고,
// 결과를 객체형으로 반환하는 프로그램 작성
// 요구사항
// 두개의 Double 객체를 생성해서 소수점 계산
// 계산된 결과를 Double 

public class DoubleWrapperEx {
	public static void main(String[] args) {
		
	}
}
