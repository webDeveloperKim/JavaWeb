package object;

public class ShapeMain {

	public static void main(String[] args) {
		Shape shape = new Shape("동그라미");
		System.out.println(shape.toString());

	}

}
