package immutable;


public class ImmutablePersonMain {
	public static void main(String[] args) {
//		아예 새로운 객체를 만드는 것
		ImmutablePerson immutablePerson = new ImmutablePerson("홍길동",18);
		
		int age = immutablePerson.getAge();
		age = 15;
		 
		System.out.println(age);
		
//		개발자들끼리 의미를 알수있다
//		바꾸면 안되는 객체인데 메서드를 통해서 새로 값으로 새 객체를 만들어서 필드를 다른 값으로 만드는 것이다.
		ImmutablePerson im = immutablePerson.withName("홍길동222", 123);
		
	}
}
