package exceptionHandling;

public class ExceptionHandlingMain {
	public static void main(String[] args) {
		ExceptionHandlingEx2 ex2 = new ExceptionHandlingEx2();
		
		try {
//			오류가 나올수 있는 코드는 try안에
			int result = ex2.divide(10, 0);
			System.out.println(result);
//			그 오류가 뭔지를 확인
		} catch (Exception e) {
			e.printStackTrace();
	//		e.getMessage();
		}finally {
			System.out.println("무조건 실행");
		}
		
	}
	
}
