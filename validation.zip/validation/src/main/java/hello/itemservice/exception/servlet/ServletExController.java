package hello.itemservice.exception.servlet;

import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Controller
public class ServletExController {
	
	@GetMapping("/error-ex")
	public void errorEx() {
		throw new RuntimeException("예외 발생"); 
	}
	
	@GetMapping("/error-404")
	public void error404(HttpServletResponse response) throws IOException {
		response.sendError(404, "404 오류");
		
	}
	
	@GetMapping("/error-500")
	public void error500(HttpServletResponse response) throws IOException {
		response.sendError(500, "500 오류");
		
	}

	/* response.sendError()를 호출하면
	 * response 내부에는 오류 발생 상태코드를 저장함
	 * 설정한 오류코드에 맞춰서 기본 오류페이지를 보여줌
	 *  
	*/
	
	
	
	
	
	
}
