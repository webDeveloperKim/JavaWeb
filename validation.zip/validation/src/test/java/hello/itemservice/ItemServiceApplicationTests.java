package hello.itemservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ItemServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
