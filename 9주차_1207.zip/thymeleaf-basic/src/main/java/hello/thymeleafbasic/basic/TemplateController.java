package hello.thymeleafbasic.basic;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/template")
public class TemplateController {
		
	// /template/fragment 매핑 url 경로
	@GetMapping("/fragment")
	public String template() {
		// 단순 화면의 경로
		return "template/fragment/fragmentMain";
	}
	
	// /template/layout 매핑 url 경로
	@GetMapping("/layout")
	public String layout() {
		return "template/layout/layoutExtendMain";
	}
	
}