package final1;

public class FieldInit {
	static final int CONST_VALUE = 10; // final 은 올 대문자 언더바로 구분
	final int value = 10;
}
