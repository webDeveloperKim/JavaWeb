package abstract2;

public class Test {
	public static void main(String[] args) {
	
	// 객체 생성 안됨 추상 메서드 정의가 안되어있음	
	AbstractAnimal abstractAnimal = new AbstractAnimal() {
		
		@Override
		public void name() {
			// TODO Auto-generated method stub
			
		}
	};
}
}
