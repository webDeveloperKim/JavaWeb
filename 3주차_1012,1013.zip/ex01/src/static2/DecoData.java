package static2;

public class DecoData {

	private int instanceValue;
	private static int staticValue;
	
	public static void staticCall(DecoData dd) {
		//dd.instanceValue++; //서로 다른 영역 , 객체를 생성해야 접근 가능
		staticValue++;
	}
	
}
