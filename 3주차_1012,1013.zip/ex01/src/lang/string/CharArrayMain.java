package lang.string;

import java.util.Arrays;

public class CharArrayMain {

	public static void main(String[] args) {
		char[] charArr = new char[] {'h','e','l','l','o'};
		String str1 = "hello";
		String str2 = new String("hello");
		String str3 = "        hello          ";
	//	char[] charArr = {'h','e','l','l','o'};
	//	char[] charArr = new char[5];
	//  charArr = {'h','e','l','l','o'};
		
	
		System.out.println(charArr.length);
		System.out.println(str1.charAt(0));
		System.out.println(str1.charAt(1));
		System.out.println(str1.charAt(2));
		System.out.println(str1.charAt(3));
		System.out.println(str2.substring(0));
		System.out.println(str2.substring(1));
		System.out.println(str2.substring(2));
		System.out.println(str2.substring(3));
		System.out.println(str2.substring(2,4));
		
		System.out.println(str2.indexOf("e"));
		
		System.out.println(str1.concat(str2));
		System.out.println(str3);
		System.out.println(str3.trim());
		
		String[] strs = {str1,str2};
		
		String s1 = "";
		for(int i = 0; i <= strs.length -1; i++) {	
			s1 += strs[i];
		}
		System.out.println(s1);
		
	//	for(String str : strs) {
		//		String s1 = "";
		//	s1 = Arrays.toString(strs);
		//	System.out.println(s1);
		//		}
		
		System.out.println(strs);
		
		}
		
		
	}


