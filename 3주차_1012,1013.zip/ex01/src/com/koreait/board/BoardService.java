package com.koreait.board;

public class BoardService {

}
