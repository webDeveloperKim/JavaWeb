package com.koreait.board;

public class Board {
	String title;
	int page;

}
