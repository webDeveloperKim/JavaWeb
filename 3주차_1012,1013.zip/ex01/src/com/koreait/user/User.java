package com.koreait.user;

public class User {

}
