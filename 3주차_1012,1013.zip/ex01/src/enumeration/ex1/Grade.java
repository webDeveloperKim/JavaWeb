package enumeration.ex1;

// enum : 변하지 않는 상수 값들을 보관해두기 위해서 사용
// 정리해서 추후 교육 예정
public class Grade extends Enum{
	
	public static final Grade BASIC = new Grade();
	public static final Grade GOLD = new Grade();
	public static final Grade DIAMOND = new Grade();
	
	private Grade() {}
	
}
