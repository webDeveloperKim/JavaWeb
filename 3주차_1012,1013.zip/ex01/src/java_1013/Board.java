package java_1013;

public class Board {

	// 게시글 번호 bno
	// 글작성자 writer
	// 글 내용 content
	
	// 매개변수 있는 생성자
	private int bno;
	private String writer;
	private String content;
	private static Board instance;
	
	//싱글턴
	public static Board getInstance() {
		//객체 반환
		//null 아닐떄만 객체 반환하는 유효성 검증
		if(instance == null) {
			instance = new Board();
		}
		return instance;
	}
	
	public Board() {
		
	}
	
	public Board(int bon,String writer,String content) {
		this.bno = bno;
		this.writer = writer;
		this.content = content;
	}
	
	public void setBno(int bno) {
		this.bno = bno;
	}
	public int getBno() {
		return bno;
	}

	public String getWriter() {
		return writer;
	}

	public void setWriter(String writer) {
		this.writer = writer;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}
	
	// 객체 생성 시점에 위에 필드 한번에 초기화 해주는거
	//	getter / setter 매서드
	
	
	public String toString(int bno, String writer, String content) {
		// TODO Auto-generated method stub
		return "글번호는" + bno + " 작성자 " + writer + "내용 " + content;
	}
}
