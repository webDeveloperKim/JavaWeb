package pack;

public class Data {
	public Data() {
		System.out.println("객체 생성");
	}
}
