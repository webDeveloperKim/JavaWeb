package pack;

import pack.a.User;

public class packageMain1 {

	public static void main(String[] args) {
		Data data = new Data();
		User use = new User();
	//  pack.a.User use = new pack.a.User();
		
	}

}
