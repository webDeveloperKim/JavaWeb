package pack.a;

public class User {
	public User() {
		System.out.println("pack.a 객체 생성");
	}
}
