package pack.a;

//import pack.Data;
//import pack.Data2;
import pack.*;

public class UserMain {

	public static void main(String[] args) {
		
		Data data = new Data();
		Data2 data2 = new Data2();

	}

}
