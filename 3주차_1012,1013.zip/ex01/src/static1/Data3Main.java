package static1;

public class Data3Main {

	public static void main(String[] args) {
		Data3 data3 = new Data3("A");
		System.out.println("A count ::" + Data3.count);
		
		Data3 data4 = new Data3("A");
		System.out.println("A count ::" + Data3.count);
		
		Data3 data5 = new Data3("A");
		System.out.println("A count ::" + Data3.count);
	
	}

}
