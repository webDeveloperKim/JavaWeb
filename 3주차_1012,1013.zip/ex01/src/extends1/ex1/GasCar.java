package extends1.ex1;

public class GasCar extends Car{

	public void fillUp() {
		System.out.println("차 주유합니다");
	}
}
 