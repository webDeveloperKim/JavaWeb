package extends1.ex1;

public class ElectricalCar extends Car {

	public void charge() {
		System.out.println("차 주유");
	}
}
