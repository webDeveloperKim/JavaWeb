package exception.basic.checked;

//클라이언트 역할을 하는 클래스 생성
public class Client {
//MyCheckedException에 error 즉 예외를 던진다 
	public void call() throws MyCheckedException{
		throw new MyCheckedException("errrrro");
	}

}
