package exception.basic.checked;

public class Service {
	Client client = new Client();
//	예외 catch 해서 처리하는 코드
	
//	exception 이 발생했을 때 catch 하는 코드임
	public void callCatch() {
		try {
			client.call(); // 일부러 예외발생 시킨 코드
//	exception 이 있으면 error 메세지를 가져와서 보여준다
		} catch (Exception e) {
			System.out.println("예외처리 메세지" + e.getMessage());
		}
		System.out.println("정상 동작");
	}
	
	public void callThrow() throws MyCheckedException{
		client.call();
	}
	
}
