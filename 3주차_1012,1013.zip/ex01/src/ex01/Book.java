package ex01;

public class Book {
	String title;
	String author;
	int page;
	
	//여기에 코드 추가해서
//	우측의 main 오류 없이 실행 가능하도록
	public Book() {
		this("","",0);
	}
	
	public Book(String title, String author) {
		this.title = title;
		this.author = author;
	}
	public Book(String title, String author,int page) {
		this.title = title;
		this.author = author;
		this.page = page;
	}
	public void displayInfo() {
		System.out.println("제목 : " + this.title + "작가 : " + this.author + "페이지" + this.page) ;
	}

}
