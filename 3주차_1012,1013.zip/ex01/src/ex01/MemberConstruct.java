package ex01;

public class MemberConstruct {
	String name;
	int age;
	int grade;
	
	public MemberConstruct() {
		System.out.println("객체생성되었음");
	}
	
	public MemberConstruct(String name, int age) {
		this.name = name;
		this.age = age;	
	}
	
	// public 은 다른 패키지에서도 접근 가능하도록 만듬
	public MemberConstruct(String name, int age, int grade) {
		this(name,age);
		this.grade = grade;
		
	}
}
