package poly.ex3;

public abstract class AbstractAnimal {
	
	public abstract void sound();
	
	public void move() {
		System.out.println("동물이 이동한다");
	};
}
