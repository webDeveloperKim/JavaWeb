package poly.basic;

public class Cow extends Animal {
	
	@Override
	public void sound() {
		System.out.println("음메");
	}
}
