package poly.basic;

public class PolyMain {

	public static void main(String[] args) {
		
		System.out.println("---1---");
		
		Parent parent = new Parent();
		parent.parentMethod();
		System.out.println("---2---");
		
		Child child = new Child();
		child.parentMethod();
		
		System.out.println("---3---");
		Parent poly = new Child();
		poly.parentMethod();
		
		int a = 10;
		long b = 20l;
		
		a = (int)b;
		
	}

}
