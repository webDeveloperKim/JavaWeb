package extends1.ex1;

public class Car {
	public void move() {
		System.out.println("차를 이동합니다");
	}
	
	public void opneDoor() {
		System.out.println("문을 연다");
	}
}
