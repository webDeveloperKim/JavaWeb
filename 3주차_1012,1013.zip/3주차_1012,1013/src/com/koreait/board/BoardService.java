package com.koreait.board;

public class BoardService {
	
	public static void main(String[] args) {
		
	
	
	Board board = new Board("동화책", 100);
	
	board.titleName();
	board.pageNumber();
	
	}
}
