package ex01;

public class MemberInit {
	
	String name;
	int age;
	int grade;
	
// 힙 영역 : 객체 생성해서 참조값 담기는 곳
// 스택 영역 : 메인 메서드 안에서
// 메모리 영역 : 공통 자원 static (객체생성없이)
	
}
