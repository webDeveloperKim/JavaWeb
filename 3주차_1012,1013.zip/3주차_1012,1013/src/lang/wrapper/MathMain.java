package lang.wrapper;

public class MathMain {

	public static void main(String[] args) {
		
	}

}
