package poly.basic;

public class Animal {
	public void sound() {
		System.out.println("동물 울음소리");
	}
}
