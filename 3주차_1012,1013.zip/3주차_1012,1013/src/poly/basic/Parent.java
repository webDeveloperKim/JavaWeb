package poly.basic;

public class Parent {
	
	public void parentMethod() {
		System.out.println("부모클래스 생성자 호출");
	}

	// 부모타입의 참조변수로 자식타입의 인스턴스를 참조할 수 있음
	// 반대로 자식타입의 참조변수로 부모타입의 인스턴스 참조할 수 없음
	
	// 다형성 사용 이유 & 이점
	// 하나의 참조변수로 다양한 자식 인스턴스를 참조할 수 있음
	
	// 메서드 오버라이딩
	
	
}
