package poly.basic;

public class Child extends Parent{
	public Child() {
		System.out.println("자식클래스 생성자호출");
	}
}
