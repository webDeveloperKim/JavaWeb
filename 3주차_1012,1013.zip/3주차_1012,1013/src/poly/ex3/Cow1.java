package poly.ex3;

public class Cow1 extends AbstractAnimal {
	
	@Override
	public void sound() {
		System.out.println("음메");
	}
	
	@Override
	public void move() {
		System.out.println("음메 이동");
	}
}
