package poly.ex3;

public class Dog1 extends AbstractAnimal {
	
	@Override
	public void sound() {
		System.out.println("멍멍");
	}
	
	@Override
	public void move() {
		System.out.println("멍멍 이동");
	}
	
}
