package pack;

public class Data2 {
	public Data2() {
		System.out.println("객체2 생성");
	}
}
