package pack;

public class Data {
	public Data() {
		System.out.println("객체1 생성");
	}
}