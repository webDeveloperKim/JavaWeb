package hello.itemservice.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;
import org.springframework.util.StringUtils;

import hello.itemservice.domain.Item;
import jakarta.persistence.EntityManager;
import jakarta.persistence.TypedQuery;
import jakarta.transaction.Transactional;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Repository
@Transactional
public class JpaItemRepositoryV1 implements ItemRepository {
	private final EntityManager em;
	
	public JpaItemRepositoryV1(EntityManager em) {
		this.em = em;
	}

	@Override
	public Item save(Item item) {
		em.persist(item); // 영속적으로 적용한다 
		// JPA 에서 객체를 테이블레 저장할때는 EntityManager 객체가 제공하는
		// persist() 사용할 것 
		return item;
	}

	@Override
	public void update(Long itemId, ItemUpdateDto updateParam) {
		Item findItem = em.find(Item.class, itemId);
		findItem.setItemName(updateParam.getItemName());
		findItem.setPrice(updateParam.getPrice());
		findItem.setQuantity(updateParam.getQuantity());
	}

	@Override
	public Optional<Item> findById(Long id) {
		Item item = em.find(Item.class, id);
		return Optional.ofNullable(item); // 널이 아니면 item 반환 
	}

	@Override
	public List<Item> findAll(ItemSearchCond cond) {
		String jpql = "select i from Item i"; // jpa 에서도 쿼리문 작성함 
		
		Integer maxPrice = cond.getMaxPrice();
		String itemName = cond.getItemName();
		
		if(StringUtils.hasText(itemName) || maxPrice != null) {
			jpql += " where";
		}
		
		boolean andFlag = false;
		
		if(StringUtils.hasText(itemName)) {
			jpql += " i.itemName like concat('%', :itemName ,'%')";
			andFlag = true;
		}
		
		if (maxPrice != null) {
			if(andFlag) {
				jpql += " and";
			}
			
			jpql += " i.price <= :maxPrice";
		}
		
		log.info("jpql={}" , jpql);
		
		// 리턴할 객체 만들 것 
		TypedQuery<Item> query = em.createQuery(jpql, Item.class);
		
		if(StringUtils.hasText(itemName)) {
			query.setParameter("itemName", itemName);
		}
		
		if(maxPrice != null) {
			query.setParameter("maxPrice", maxPrice);
		}
		
		//List <item> 타입으로 반환함 
		return query.getResultList();
	}
	
}



















