package study1;

public class StringOutput3 {

	public static void main(String[] args) {

		//printf 는 특정한 문자 형식에 맞춰서 출력하게 해줍니다.
		String string = "JAVA";
		int number = 123123;
		
		System.out.printf("JAVA : %s \t %d", string, number);
		
	}

}
