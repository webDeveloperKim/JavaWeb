package study1;

public class Variance2 {

	public static void main(String[] args) {

		int x;
		x = 12; // 오른쪽에서 왼쪽에 값을 할당 
		
		int y = 12;
		
		int f = 12, g = 123, gg = 1234;
		//System.out.println(f, g, gg);
		//안됨
		System.out.println("f , g , gg");
		
		System.out.println(1234 + ",");
		
		char ch = '가';
		System.out.println(ch);
		
		
	}

}
