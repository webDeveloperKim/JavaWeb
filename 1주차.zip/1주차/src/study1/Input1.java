package study1;

import java.util.Scanner;

public class Input1 {

	public static void main(String[] args) {
	
//		Scanner를 사용해서 입력받는 방법 
		Scanner A = new Scanner(System.in);
		String B = A.next();
		
		System.out.println(A); 
		System.out.println(A.next());

	}

}