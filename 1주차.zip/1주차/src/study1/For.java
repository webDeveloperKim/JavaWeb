package study1;

public class For {

		public static void main(String[] args) {
	
	//	i가 1부터 시작해서 100이하까지 1씩 증가하면서 화면 출력하는 코드 (for문 사용)
		for(int i =1; i <= 100; i++) {
				System.out.printf("i = %d\n",i);
					
		}
					
	}
				
}
	
