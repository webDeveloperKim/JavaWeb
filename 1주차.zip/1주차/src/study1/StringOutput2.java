package study1;

public class StringOutput2 {

	public static void main(String[] args) {
		
// string1 , string2 변수에 문자열을 각각 지정한 후 println 에서 + 로 문자열을 결합 후 출  
		String string1 = "가가가";
		String string2 = "나나나";
		
		System.out.println(string1+string2); 
		
	}

}
