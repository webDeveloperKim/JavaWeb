package study1;

public class StringOutput {

	public static void main(String[] args) {

//		"홍길동" 문자열 출력
		String name = "\"홍길동\"";
		System.out.println(name);

//		앞에 텝 사용 후 홍길동 문자A열 출력
		name = "\t홍길동";
		System.out.println(name);
		
	}

}
