package study1;

public class Input2 {

	public static void main(String[] args) {
		
//		int a 에 10이 담기고 선 1증감 후 1증감 확인해보는 코드 
		int a = 10;
		++a;
		System.out.println(++a);
		System.out.println(a++);
		System.out.println(a);
		
		
		
	}

}