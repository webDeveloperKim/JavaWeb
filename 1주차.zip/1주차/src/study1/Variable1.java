package study1;

public class Variable1 {

	public static void main(String[] args) {
			final String recruitName = "25년도 대졸공채";
//			recruitName = "상시 채용";
			//final 키워드 붙어서 상수라 안 바뀜
	
			System.out.println("이번채용공고는 : " + recruitName);
			}
}
