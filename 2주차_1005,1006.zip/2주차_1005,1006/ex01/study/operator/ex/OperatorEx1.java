package operator.ex;

public class OperatorEx1 {

	public static void main(String[] args) {
//	문제1
//		num1, num2, num3 세개의 int 타입 변수를 선언하고, 각각 10 20 30으로 초기화
//		세 변수의 합을 계산하고 그 결과를 sum이라는 이름의 변수에 저장
//		세 변수의 평균을 계산하고 그 결과를 average 라는 이름의 변수에 저장
//		이때 소수점 이하의 결과는 버림하세요
//		최종 sum과 average 변수의 값을 출력하세요

		int num1 = 10;
		int num2 = 22;
		int num3 = 35;
		
		int sum = 0;
		
		double average = 0;
		
		sum = num1 + num2 + num3;
		System.out.println("sum =" + sum);
		
		average = (double)sum / 3;
		System.out.println((int)average);
		
		
		
	}

}
