package operator;

public class Operator4 {

	public static void main(String[] args) {
//		증감연산자
		
		int a = 0;
		
		a++;
		a = a + 1; // 자기 자신에게 1을 더하고 다시 대입해준다
		
		++a; // 변수에 들어있는 숫자값을 1 증가 시킨다 > 이후 연산
		
		a++; // 
		
		
		
	}

}
