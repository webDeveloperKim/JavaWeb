package a_variable;

public class Var3 {

	public static void main(String[] args) {
//		데이터 타입 ( = 자료형 )
//		정수
		int a = 100; //거의 모든 숫자 데이터에 사용함 ( 표현범위 20억 넘어가지 않는 이상 int 사용)
		long b = 1111111111111111111L;
		
//		실수
		double c = 10.5; //대부분의 소숫점 데이터 다룰때 사용 (정밀도 높음)
		
//		논리형
		boolean d = true; // 불린 , 불리언 
//		( 조건문에서 자주 쓰임 )
		
//		문자열
		String e = "hello";
		String f = "h";
		char g = 'd';
		
 
	}

}
