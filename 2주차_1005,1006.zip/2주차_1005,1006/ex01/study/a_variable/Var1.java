package a_variable;

public class Var1 {

	public static void main(String[] args) {
//		변수 사용 목적
//		값 저장 & 코드 중복 제거
		
		System.out.println("10");
		System.out.println("10");
		System.out.println("10");
		System.out.println("10");
		
		System.out.println("-----------");
		
//		지역변수는 반드시 초기값을 넣어주어야 함
		int a = 12;
		System.out.println(a);
		System.out.println(a);
		System.out.println(a);
		System.out.println(a);
		
		final String USER_ID = "user1";
//		USER_ID = "1234";
		
//		자주쓰는 단축키
		/*
		 * 1)세로열 일괄 선택
		 * ALT + Shift + a
		 * 
		 * 2)문장 주석
		 * Ctrl + 명령키(위, 아래)
		 * 
		 * 3)문장 위아래 이동시키기
		 * Alt + 방향키
		 * 
		 * 
		 */
		
		
		

	}

}
