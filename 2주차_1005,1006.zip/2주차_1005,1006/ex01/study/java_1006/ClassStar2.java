package java_1006;

public class ClassStar2 {

	public static void main(String[] args) {
		
//		배열 복습 문제
//		배열은 특정 타입을 연속한 데이터 구조로 만들어
//		하나의 변수로 관리할 수 있음
		
//		int[] aa = new int[3];
//		int[] aa2 = new int[]{11,22,33};
		
		
		String[] student1Names = {"학생1", "학생2"};
		int[] student1Ages = {15, 16};
		int[] Student1Grades = {90, 80};
				
		System.out.println("이름 : " + student1Names[0] + "나이 : " + student1Ages[0] + "성적 : " + Student1Grades[0]);
		System.out.println("이름 : " + student1Names[1] + "나이 : " + student1Ages[1] + "성적 : " + Student1Grades[1]);

//		for문의 조건식 구성
//		초기식 : 반복을 시작할 횟수 i (=카운트변수)
//		조건식 : 반복문을 종료시키는 조건 (총 반복횟수의 limit 값)
//		증감식 : 카운트 변수 i가 종료조건을 타기 위한 코드
		
		System.out.println(student1Names.length);
		
		for(int i = 0; i < student1Names.length; i++) {
			System.out.println("이름 : " + student1Names[i] + "나이 : " + student1Ages[i] + "성적 : " + Student1Grades[i]);
		}
		
		
	}

}
