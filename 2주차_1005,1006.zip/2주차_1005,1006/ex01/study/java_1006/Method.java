package java_1006;

public class Method {
	// 두 숫자를 입력받아서 더하고 출력하는 
	// 단순 기능을 매서드로 만들어보세요
	// 먼저 1 + 2를 수령하고, 
	// 그 다음으로 10 + 20을 계산하도록
	
	int a = 1;
	int b = 2;
	
	// 매서드 오버로딩 ( 코드 재사용 )
	public int add(int a, int b) {
		int sum = 0;
		sum = a + b;
		return sum;
}
	public int add(int a, String b) {
		int sum = 0;
		return sum;
}
}