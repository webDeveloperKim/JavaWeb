package java_1006;

public class MemberMain {

	public static void main(String[] args) {
		Member member = new Member();
	//member.name = "회원1";
	//member.age = 15;
	//member.grade = 5;
		
		member.initMember("회원1", 15, 5);

		System.out.println("name : " + member.name + "age : " + member.age + "grade : " + member.grade);
	}

}
